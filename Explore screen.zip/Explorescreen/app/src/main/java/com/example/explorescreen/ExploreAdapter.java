package com.example.explorescreen;

public class ExploreAdapter {
    public ExploreAdapter(List<String> items) {
    }
}
