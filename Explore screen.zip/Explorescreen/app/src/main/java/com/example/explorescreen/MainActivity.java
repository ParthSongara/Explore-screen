package com.example.explorescreen;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get references to UI elements
        ImageView headerImageView = findViewById(R.id.headerImageView);
        TextView titleTextView = findViewById(R.id.titleTextView);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        // Set header image
        headerImageView.setImageResource(R.drawable.explore_header_image);

        // Set up the RecyclerView with a LayoutManager and an adapter
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(layoutManager);

        // Create a list of items to display (replace with your actual data)
        List<String> items = new ArrayList<>();
        items.add("Item 1");
        items.add("Item 2");
        items.add("Item 3");
        // ...

        // Create an adapter and set it on the RecyclerView
        RecyclerView.Adapter adapter = new ExploreAdapter(items);
        recyclerView.setAdapter(adapter);
    }

}